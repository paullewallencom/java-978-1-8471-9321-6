
package com.binildas.apache.axis.AxisSpring;

public interface IHello{

	String hello(String param);

}