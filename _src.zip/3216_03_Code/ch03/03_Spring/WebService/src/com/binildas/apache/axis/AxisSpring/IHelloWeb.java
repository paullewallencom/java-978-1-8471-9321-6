
package com.binildas.apache.axis.AxisSpring;

public interface IHelloWeb extends IHello{

}