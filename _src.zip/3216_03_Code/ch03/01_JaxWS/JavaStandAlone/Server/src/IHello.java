
package com.binildas.ws.javastandalone.simple;


public interface IHello{

  String sayHello (String name);

}
