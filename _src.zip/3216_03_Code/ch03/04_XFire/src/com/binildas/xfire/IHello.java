package com.binildas.xfire;

public interface IHello{

    String sayHello(String name);

}