
package com.binildas.apache.axis.AxisEndToEnd;

public interface IHelloWeb{

    public String hello(String param);
}
