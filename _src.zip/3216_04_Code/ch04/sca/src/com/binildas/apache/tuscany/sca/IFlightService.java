
package com.binildas.apache.tuscany.sca;

public interface IFlightService{

    String bookFlight(String date, int seats, String flightClass);
}
