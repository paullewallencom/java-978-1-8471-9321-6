
package com.binildas.apache.tuscany.sca;

public interface IHotelService{

    String bookHotel(String date, int beds, String hotelClass);
}
