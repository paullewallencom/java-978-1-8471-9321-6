
package com.binildas.apache.tuscany.sca;

public interface IBookingAgent{

    String bookTourPackage(String date, int people, String tourPack);
}
