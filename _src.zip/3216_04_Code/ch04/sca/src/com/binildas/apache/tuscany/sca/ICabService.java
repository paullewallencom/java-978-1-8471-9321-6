
package com.binildas.apache.tuscany.sca;

public interface ICabService{

    String bookCab(String date, String cabType);
}
